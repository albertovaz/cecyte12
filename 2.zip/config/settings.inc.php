<?php
define('_DB_SERVER_', 'localhost');
define('_DB_NAME_', 'prestashop');
define('_DB_USER_', 'root');
define('_DB_PASSWD_', '');
define('_DB_PREFIX_', 'ps_');
define('_MYSQL_ENGINE_', 'InnoDB');
define('_PS_CACHING_SYSTEM_', 'CacheMemcache');
define('_PS_CACHE_ENABLED_', '0');
define('_COOKIE_KEY_', 'iTb0q4INU6GiK1WQQXdy2jmbXfPscdP9QFxOoDXg4g5WgQ9hZg4HWxw3');
define('_COOKIE_IV_', 'VXHmCKVV');
define('_PS_CREATION_DATE_', '2016-08-08');
if (!defined('_PS_VERSION_'))
	define('_PS_VERSION_', '1.6.1.6');
define('_RIJNDAEL_KEY_', 'EtPINi0tnyN3FcLtXAAXsnXEA7gJV9IH');
define('_RIJNDAEL_IV_', 'n+Pd5Krj8mKcuMNZ/QyXMg==');
