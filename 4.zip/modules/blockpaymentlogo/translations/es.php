<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_eaaf494f0c90a2707d768a9df605e94b'] = 'Bloque de logos de pago';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_3fd11fa0ede1bd0ace9b3fcdbf6a71c9'] = 'Agrega un bloque que muestra todos los logos de pago.';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_efc226b17e0532afff43be870bff0de7'] = 'La configuración ha sido actualizada.';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_5c5e5371da7ab2c28d1af066a1a1cc0d'] = 'Página CMS no disponible';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_829cb250498661a9f98a58dc670a9675'] = 'Página de destino para el bloque de enlaces';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';


return $_MODULE;
