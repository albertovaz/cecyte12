<?php /* Smarty version Smarty-3.1.19, created on 2016-08-08 14:00:56
         compiled from "C:\xampp\htdocs\tienda\admin977gbqrpt\themes\default\template\content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1468557a8d6e8953a81-35869835%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '140c51300649e651fba9a8d0efc5e2baaa1e0b14' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda\\admin977gbqrpt\\themes\\default\\template\\content.tpl',
      1 => 1470677469,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1468557a8d6e8953a81-35869835',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57a8d6e895b793_83279917',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57a8d6e895b793_83279917')) {function content_57a8d6e895b793_83279917($_smarty_tpl) {?>
<div id="ajax_confirmation" class="alert alert-success hide"></div>

<div id="ajaxBox" style="display:none"></div>


<div class="row">
	<div class="col-lg-12">
		<?php if (isset($_smarty_tpl->tpl_vars['content']->value)) {?>
			<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

		<?php }?>
	</div>
</div><?php }} ?>
