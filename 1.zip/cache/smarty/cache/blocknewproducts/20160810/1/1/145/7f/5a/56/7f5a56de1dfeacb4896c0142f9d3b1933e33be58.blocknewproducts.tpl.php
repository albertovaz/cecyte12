<?php /*%%SmartyHeaderCode:683557aa05ac96ada2-45202579%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7f5a56de1dfeacb4896c0142f9d3b1933e33be58' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda\\themes\\default-bootstrap\\modules\\blocknewproducts\\blocknewproducts.tpl',
      1 => 1470677546,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '683557aa05ac96ada2-45202579',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab3329201452_23206718',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab3329201452_23206718')) {function content_57ab3329201452_23206718($_smarty_tpl) {?><!-- MODULE Block new products -->
<div id="new-products_block_right" class="block products_block">
	<h4 class="title_block">
    	<a href="http://localhost/tienda/nuevos-productos" title="Novedades">Novedades</a>
    </h4>
    <div class="block_content products-block">
                    <ul class="products">
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://localhost/tienda/gadgets/11-teclado-smartab-bt-017-bluetooth-para-telefono-ipad-tablet-compatible-con-android-ios-negro.html" title="Teclado Smartab Bt-017 Bluetooth Para teléfono Ipad Tablet Compatible con Android iOS -Negro"><img class="replace-2x img-responsive" src="http://localhost/tienda/26-small_default/teclado-smartab-bt-017-bluetooth-para-telefono-ipad-tablet-compatible-con-android-ios-negro.jpg" alt="Teclado Smartab Bt-017 Bluetooth Para teléfono Ipad Tablet Compatible con Android iOS -Negro" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://localhost/tienda/gadgets/11-teclado-smartab-bt-017-bluetooth-para-telefono-ipad-tablet-compatible-con-android-ios-negro.html" title="Teclado Smartab Bt-017 Bluetooth Para teléfono Ipad Tablet Compatible con Android iOS -Negro">Teclado Smartab Bt-017 Bluetooth Para teléfono Ipad Tablet Compatible con Android iOS -Negro</a>
                            </h5>
                        	<p class="product-description">TECLADO BLUETOOTHPARA TELÉFONO TABLETCOMPATIBLE CON ANDROIDCOMPATIBLE...</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	150,80 $                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://localhost/tienda/gadgets/10-soporte-magnetico-giratorio-para-celular-universal.html" title="Soporte Magnético Giratorio para Celular Universal"><img class="replace-2x img-responsive" src="http://localhost/tienda/25-small_default/soporte-magnetico-giratorio-para-celular-universal.jpg" alt="Soporte Magnético Giratorio para Celular Universal" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://localhost/tienda/gadgets/10-soporte-magnetico-giratorio-para-celular-universal.html" title="Soporte Magnético Giratorio para Celular Universal">Soporte Magnético Giratorio para Celular Universal</a>
                            </h5>
                        	<p class="product-description">Diseño Innovador.
Chupón adherible.
Mecanismo de succión y extracción....</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	191,40 $                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://localhost/tienda/gadgets/9-audifonos-panasonic-rphv-41-negro.html" title="Audífonos Panasonic RPHV-41-Negro"><img class="replace-2x img-responsive" src="http://localhost/tienda/24-small_default/audifonos-panasonic-rphv-41-negro.jpg" alt="Audífonos Panasonic RPHV-41-Negro" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://localhost/tienda/gadgets/9-audifonos-panasonic-rphv-41-negro.html" title="Audífonos Panasonic RPHV-41-Negro">Audífonos Panasonic RPHV-41-Negro</a>
                            </h5>
                        	<p class="product-description">Bocinas botón
Ergonómicos
Entrada 3.5 mm
Aislan ruido ambienta</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	243,60 $                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://localhost/tienda/gadgets/8-tablet.html" title="Reloj Celular Localizador Rastreador Tracker Gps T58 con Aplicacion para Smartphone"><img class="replace-2x img-responsive" src="http://localhost/tienda/27-small_default/tablet.jpg" alt="Reloj Celular Localizador Rastreador Tracker Gps T58 con Aplicacion para Smartphone" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://localhost/tienda/gadgets/8-tablet.html" title="Reloj Celular Localizador Rastreador Tracker Gps T58 con Aplicacion para Smartphone">Reloj Celular Localizador Rastreador Tracker Gps T58 con Aplicacion para Smartphone</a>
                            </h5>
                        	<p class="product-description">Es un elegante reloj de pulso que te da la hora y fecha
Es un celular...</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	0,00 $                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                            </ul>
            <div>
                <a href="http://localhost/tienda/nuevos-productos" title="Todas los nuevos productos" class="btn btn-default button button-small"><span>Todas los nuevos productos<i class="icon-chevron-right right"></i></span></a>
            </div>
            </div>
</div>
<!-- /MODULE Block new products --><?php }} ?>
