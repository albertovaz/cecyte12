<?php /*%%SmartyHeaderCode:1823557aa054924b864-79000529%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b2181a7499cebb8d4d00c029d5259d635f94ddd5' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda\\modules\\blocknewproducts\\views\\templates\\hook\\tab.tpl',
      1 => 1470677530,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1823557aa054924b864-79000529',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab59c522eb92_21719772',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab59c522eb92_21719772')) {function content_57ab59c522eb92_21719772($_smarty_tpl) {?><li><a data-toggle="tab" href="#blocknewproducts" class="blocknewproducts">Nuevos</a></li>
<?php }} ?>
