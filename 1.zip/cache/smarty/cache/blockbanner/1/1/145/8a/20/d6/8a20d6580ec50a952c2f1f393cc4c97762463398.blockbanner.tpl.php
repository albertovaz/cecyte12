<?php /*%%SmartyHeaderCode:190257a8d69a9575e9-14816560%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8a20d6580ec50a952c2f1f393cc4c97762463398' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda\\modules\\blockbanner\\blockbanner.tpl',
      1 => 1470677526,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '190257a8d69a9575e9-14816560',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab32b5e1d3b8_02356348',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab32b5e1d3b8_02356348')) {function content_57ab32b5e1d3b8_02356348($_smarty_tpl) {?><a href="http://localhost/tienda/" title="">
	<img class="img-responsive" src="http://localhost/tienda/modules/blockbanner/img/sale70.png" alt="" title="" width="1170" height="65" />
</a>
<?php }} ?>
