<?php /*%%SmartyHeaderCode:898357a8d6996614a4-20447824%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b202981ec01635e2203c1bbf2305b87ff7974567' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda\\themes\\default-bootstrap\\modules\\blocksocial\\blocksocial.tpl',
      1 => 1470677546,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '898357a8d6996614a4-20447824',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab32b5320921_43852338',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab32b5320921_43852338')) {function content_57ab32b5320921_43852338($_smarty_tpl) {?><section id="social_block" class="pull-right">
	<ul>
					<li class="facebook">
				<a class="_blank" href="http://www.facebook.com/prestashop">
					<span>Facebook</span>
				</a>
			</li>
							<li class="twitter">
				<a class="_blank" href="http://www.twitter.com/prestashop">
					<span>Twitter</span>
				</a>
			</li>
							<li class="rss">
				<a class="_blank" href="http://www.prestashop.com/blog/en/">
					<span>RSS</span>
				</a>
			</li>
		                        	<li class="google-plus">
        		<a class="_blank" href="https://www.google.com/+prestashop" rel="publisher">
        			<span>Google Plus</span>
        		</a>
        	</li>
                                	</ul>
    <h4>Síganos</h4>
</section>
<div class="clearfix"></div>
<?php }} ?>
