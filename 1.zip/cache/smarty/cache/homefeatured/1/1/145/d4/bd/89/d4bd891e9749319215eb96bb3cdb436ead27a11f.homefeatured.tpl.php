<?php /*%%SmartyHeaderCode:2916557aa054a1af7d3-40347548%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd4bd891e9749319215eb96bb3cdb436ead27a11f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda\\themes\\default-bootstrap\\modules\\homefeatured\\homefeatured.tpl',
      1 => 1470677547,
      2 => 'file',
    ),
    '862138ed60f9f5b98663b9b7afdd1fe2d3265c1f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda\\themes\\default-bootstrap\\product-list.tpl',
      1 => 1470677542,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2916557aa054a1af7d3-40347548',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab59c5743947_54101824',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab59c5743947_54101824')) {function content_57ab59c5743947_54101824($_smarty_tpl) {?>		
									
		
	
	<!-- Products list -->
	<ul id="homefeatured" class="product_list grid row homefeatured tab-pane">
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 first-in-line last-line first-item-of-tablet-line first-item-of-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://localhost/tienda/gadgets/8-tablet.html" title="Reloj Celular Localizador Rastreador Tracker Gps T58 con Aplicacion para Smartphone" itemprop="url">
							<img class="replace-2x img-responsive" src="http://localhost/tienda/27-home_default/tablet.jpg" alt="Reloj Celular Localizador Rastreador Tracker Gps T58 con Aplicacion para Smartphone" title="Reloj Celular Localizador Rastreador Tracker Gps T58 con Aplicacion para Smartphone"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://localhost/tienda/gadgets/8-tablet.html" rel="http://localhost/tienda/gadgets/8-tablet.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://localhost/tienda/gadgets/8-tablet.html" rel="http://localhost/tienda/gadgets/8-tablet.html">
							<span>Vista r&aacute;pida</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										0,00 $									</span>
									<meta itemprop="priceCurrency" content="MXN" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />En stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://localhost/tienda/gadgets/8-tablet.html">
								<span class="new-label">Nuevo</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://localhost/tienda/gadgets/8-tablet.html" title="Reloj Celular Localizador Rastreador Tracker Gps T58 con Aplicacion para Smartphone" itemprop="url" >
							Reloj Celular Localizador Rastreador...
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Es un elegante reloj de pulso que te da la hora y fecha
Es un celular que te permite hacer llamadas a 10 números previamente guardados en el reloj y recibir llamadas y enviar y recibir audios tipo whatsapp
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								0,00 $							</span>
														
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="http://localhost/tienda/carrito?add=1&amp;id_product=8&amp;token=06fdb1fac354e099c71526ebfc9a01a1" rel="nofollow" title="A&ntilde;adir al carrito" data-id-product-attribute="0" data-id-product="8" data-minimal_quantity="1">
									<span>A&ntilde;adir al carrito</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://localhost/tienda/gadgets/8-tablet.html" title="Ver">
							<span>M&aacute;s</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class=" label-success">
										En stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-line last-item-of-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://localhost/tienda/gadgets/9-audifonos-panasonic-rphv-41-negro.html" title="Audífonos Panasonic RPHV-41-Negro" itemprop="url">
							<img class="replace-2x img-responsive" src="http://localhost/tienda/24-home_default/audifonos-panasonic-rphv-41-negro.jpg" alt="Audífonos Panasonic RPHV-41-Negro" title="Audífonos Panasonic RPHV-41-Negro"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://localhost/tienda/gadgets/9-audifonos-panasonic-rphv-41-negro.html" rel="http://localhost/tienda/gadgets/9-audifonos-panasonic-rphv-41-negro.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://localhost/tienda/gadgets/9-audifonos-panasonic-rphv-41-negro.html" rel="http://localhost/tienda/gadgets/9-audifonos-panasonic-rphv-41-negro.html">
							<span>Vista r&aacute;pida</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										243,60 $									</span>
									<meta itemprop="priceCurrency" content="MXN" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/OutOfStock" />Agotado
																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://localhost/tienda/gadgets/9-audifonos-panasonic-rphv-41-negro.html">
								<span class="new-label">Nuevo</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://localhost/tienda/gadgets/9-audifonos-panasonic-rphv-41-negro.html" title="Audífonos Panasonic RPHV-41-Negro" itemprop="url" >
							Audífonos Panasonic RPHV-41-Negro
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Bocinas botón
Ergonómicos
Entrada 3.5 mm
Aislan ruido ambienta
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								243,60 $							</span>
														
							
							
											</div>
										<div class="button-container">
																					<span class="button ajax_add_to_cart_button btn btn-default disabled">
									<span>A&ntilde;adir al carrito</span>
								</span>
																			<a class="button lnk_view btn btn-default" href="http://localhost/tienda/gadgets/9-audifonos-panasonic-rphv-41-negro.html" title="Ver">
							<span>M&aacute;s</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class="label-danger">
										Agotado
									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-line last-item-of-tablet-line first-item-of-mobile-line last-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://localhost/tienda/gadgets/10-soporte-magnetico-giratorio-para-celular-universal.html" title="Soporte Magnético Giratorio para Celular Universal" itemprop="url">
							<img class="replace-2x img-responsive" src="http://localhost/tienda/25-home_default/soporte-magnetico-giratorio-para-celular-universal.jpg" alt="Soporte Magnético Giratorio para Celular Universal" title="Soporte Magnético Giratorio para Celular Universal"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://localhost/tienda/gadgets/10-soporte-magnetico-giratorio-para-celular-universal.html" rel="http://localhost/tienda/gadgets/10-soporte-magnetico-giratorio-para-celular-universal.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://localhost/tienda/gadgets/10-soporte-magnetico-giratorio-para-celular-universal.html" rel="http://localhost/tienda/gadgets/10-soporte-magnetico-giratorio-para-celular-universal.html">
							<span>Vista r&aacute;pida</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										191,40 $									</span>
									<meta itemprop="priceCurrency" content="MXN" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/OutOfStock" />Agotado
																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://localhost/tienda/gadgets/10-soporte-magnetico-giratorio-para-celular-universal.html">
								<span class="new-label">Nuevo</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://localhost/tienda/gadgets/10-soporte-magnetico-giratorio-para-celular-universal.html" title="Soporte Magnético Giratorio para Celular Universal" itemprop="url" >
							Soporte Magnético Giratorio para Celular...
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Diseño Innovador.
Chupón adherible.
Mecanismo de succión y extracción.
Adaptable a cualquier celular.
Tuerca fijadora.
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								191,40 $							</span>
														
							
							
											</div>
										<div class="button-container">
																					<span class="button ajax_add_to_cart_button btn btn-default disabled">
									<span>A&ntilde;adir al carrito</span>
								</span>
																			<a class="button lnk_view btn btn-default" href="http://localhost/tienda/gadgets/10-soporte-magnetico-giratorio-para-celular-universal.html" title="Ver">
							<span>M&aacute;s</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class="label-danger">
										Agotado
									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-in-line last-line first-item-of-tablet-line last-item-of-mobile-line last-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://localhost/tienda/gadgets/11-teclado-smartab-bt-017-bluetooth-para-telefono-ipad-tablet-compatible-con-android-ios-negro.html" title="Teclado Smartab Bt-017 Bluetooth Para teléfono Ipad Tablet Compatible con Android iOS -Negro" itemprop="url">
							<img class="replace-2x img-responsive" src="http://localhost/tienda/26-home_default/teclado-smartab-bt-017-bluetooth-para-telefono-ipad-tablet-compatible-con-android-ios-negro.jpg" alt="Teclado Smartab Bt-017 Bluetooth Para teléfono Ipad Tablet Compatible con Android iOS -Negro" title="Teclado Smartab Bt-017 Bluetooth Para teléfono Ipad Tablet Compatible con Android iOS -Negro"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://localhost/tienda/gadgets/11-teclado-smartab-bt-017-bluetooth-para-telefono-ipad-tablet-compatible-con-android-ios-negro.html" rel="http://localhost/tienda/gadgets/11-teclado-smartab-bt-017-bluetooth-para-telefono-ipad-tablet-compatible-con-android-ios-negro.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://localhost/tienda/gadgets/11-teclado-smartab-bt-017-bluetooth-para-telefono-ipad-tablet-compatible-con-android-ios-negro.html" rel="http://localhost/tienda/gadgets/11-teclado-smartab-bt-017-bluetooth-para-telefono-ipad-tablet-compatible-con-android-ios-negro.html">
							<span>Vista r&aacute;pida</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										150,80 $									</span>
									<meta itemprop="priceCurrency" content="MXN" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/OutOfStock" />Agotado
																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://localhost/tienda/gadgets/11-teclado-smartab-bt-017-bluetooth-para-telefono-ipad-tablet-compatible-con-android-ios-negro.html">
								<span class="new-label">Nuevo</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://localhost/tienda/gadgets/11-teclado-smartab-bt-017-bluetooth-para-telefono-ipad-tablet-compatible-con-android-ios-negro.html" title="Teclado Smartab Bt-017 Bluetooth Para teléfono Ipad Tablet Compatible con Android iOS -Negro" itemprop="url" >
							Teclado Smartab Bt-017 Bluetooth Para...
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						TECLADO BLUETOOTHPARA TELÉFONO TABLETCOMPATIBLE CON ANDROIDCOMPATIBLE CON iOS10 METROS DE ALCANCE
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								150,80 $							</span>
														
							
							
											</div>
										<div class="button-container">
																					<span class="button ajax_add_to_cart_button btn btn-default disabled">
									<span>A&ntilde;adir al carrito</span>
								</span>
																			<a class="button lnk_view btn btn-default" href="http://localhost/tienda/gadgets/11-teclado-smartab-bt-017-bluetooth-para-telefono-ipad-tablet-compatible-con-android-ios-negro.html" title="Ver">
							<span>M&aacute;s</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class="label-danger">
										Agotado
									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
		</ul>





<?php }} ?>
