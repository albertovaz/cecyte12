<?php /*%%SmartyHeaderCode:1649657aa054ba14451-22113605%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '51de57be035286439bb9e525f148af0dbb6e2644' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda\\themes\\default-bootstrap\\modules\\homeslider\\homeslider.tpl',
      1 => 1470677547,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1649657aa054ba14451-22113605',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab59c5cf89a7_89332705',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab59c5cf89a7_89332705')) {function content_57ab59c5cf89a7_89332705($_smarty_tpl) {?><!-- Module HomeSlider -->
    		<div id="homepage-slider">
						<ul id="homeslider" style="max-height:749px;">
															<li class="homeslider-container">
							<a href="http://www.prestashop.com/?utm_source=back-office&amp;utm_medium=v16_homeslider&amp;utm_campaign=back-office-ES&amp;utm_content=download" title="sample-1">
								<img src="http://localhost/tienda/modules/homeslider/images/7fc4c49d368eb9c327e073b4db50e7f522795b25_tira1.jpg" width="1024" height="749" alt="sample-1" />
							</a>
															<div class="homeslider-description"><h2>EXCEPTEUR<br />OCCAECAT</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin tristique in tortor et dignissim. Quisque non tempor leo. Maecenas egestas sem elit</p>
<p><button class="btn btn-default" type="button">Shop now !</button></p></div>
													</li>
																				<li class="homeslider-container">
							<a href="http://www.prestashop.com/?utm_source=back-office&amp;utm_medium=v16_homeslider&amp;utm_campaign=back-office-ES&amp;utm_content=download" title="sample-2">
								<img src="http://localhost/tienda/modules/homeslider/images/80ab8014f27d4b3b21f9b0a6bba144991b108f6d_tira2.jpg" width="1500" height="1000" alt="sample-2" />
							</a>
															<div class="homeslider-description"><h2>EXCEPTEUR<br />OCCAECAT</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin tristique in tortor et dignissim. Quisque non tempor leo. Maecenas egestas sem elit</p>
<p><button class="btn btn-default" type="button">Shop now !</button></p></div>
													</li>
																				<li class="homeslider-container">
							<a href="http://www.prestashop.com/?utm_source=back-office&amp;utm_medium=v16_homeslider&amp;utm_campaign=back-office-ES&amp;utm_content=download" title="sample-3">
								<img src="http://localhost/tienda/modules/homeslider/images/c81073443a513c968a4d1777c6b5ebcfcd56aa4a_tira3.jpg" width="1600" height="900" alt="sample-3" />
							</a>
															<div class="homeslider-description"><h2>EXCEPTEUR<br />OCCAECAT</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin tristique in tortor et dignissim. Quisque non tempor leo. Maecenas egestas sem elit</p>
<p><button class="btn btn-default" type="button">Shop now !</button></p></div>
													</li>
												</ul>
		</div>
	<!-- /Module HomeSlider -->
<?php }} ?>
