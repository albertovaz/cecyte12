<?php /*%%SmartyHeaderCode:896457a8d6998a75b6-96147310%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '71781ed0a57af7c2ca29e9cbcc772062abdc3be3' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda\\themes\\default-bootstrap\\modules\\blockcategories\\blockcategories_footer.tpl',
      1 => 1470677545,
      2 => 'file',
    ),
    'af53a43862bbbd36ff4c72a2ae01123302b5dc2d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda\\themes\\default-bootstrap\\modules\\blockcategories\\category-tree-branch.tpl',
      1 => 1470677545,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '896457a8d6998a75b6-96147310',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab32b5589cb6_35936325',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab32b5589cb6_35936325')) {function content_57ab32b5589cb6_35936325($_smarty_tpl) {?>
<!-- Block categories module -->
<section class="blockcategories_footer footer-block col-xs-12 col-sm-2">
	<h4>Categorías</h4>
	<div class="category_footer toggle-footer">
		<div class="list">
			<ul class="tree dhtml">
												
<li >
	<a 
	href="http://localhost/tienda/3-mujer" title="Aquí encontrarás todas las colecciones de moda de mujer.  
 Esta categoría incluye todos los básicos de tu armario y mucho más: 
 ¡zapatos, complementos, camisetas estampadas, vestidos muy femeninos y vaqueros para mujer!">
		Mujer
	</a>
			<ul>
												
<li >
	<a 
	href="http://localhost/tienda/4-tops" title="Aquí encontrarás camisetas, tops, blusas, camisetas de manga corta, de manga larga, sin mangas, de media manga y mucho más. 
 ¡Encuentra el corte que mejor te quede!">
		Tops
	</a>
			<ul>
												
<li >
	<a 
	href="http://localhost/tienda/5-camisetas" title="Los must have de tu armario; ¡échale un vistazo a los diferentes colores, 
 formas y estilos de nuestra colección!">
		Camisetas
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://localhost/tienda/7-blusas" title="Combina tus blusas preferidas con los accesorios perfectos para un look deslumbrante.">
		Blusas
	</a>
	</li>

									</ul>
	</li>

																
<li class="last">
	<a 
	href="http://localhost/tienda/8-vestidos" title="¡Encuentra tus vestidos favoritos entre nuestra amplia colección de vestidos de noche, vestidos informales y vestidos veraniegos! 
 Te ofrecemos vestidos para todos los días, para cualquier estilo y cualquier ocasión.">
		Vestidos
	</a>
			<ul>
												
<li >
	<a 
	href="http://localhost/tienda/9-vestidos-informales" title="¿Estás buscando un vestido para todos los días? Échale un vistazo a 
 nuestra selección para encontrar el vestido perfecto.">
		Vestidos informales
	</a>
	</li>

																
<li >
	<a 
	href="http://localhost/tienda/10-vestidos-noche" title="¡Descubre nuestra colección y encuentra el vestido perfecto para una velada inolvidable!">
		Vestidos de noche
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://localhost/tienda/11-vestidos-verano" title="Cortos, largos, de seda, estampados... aquí encontrarás el vestido perfecto para el verano.">
		Vestidos de verano
	</a>
	</li>

									</ul>
	</li>

									</ul>
	</li>

							
																
<li class="last">
	<a 
	href="http://localhost/tienda/12-gadgets" title="Un   gadget   es un dispositivo que tiene un propósito y una función específica, generalmente de pequeñas proporciones, práctico y a la vez novedoso.">
		Gadgets
	</a>
	</li>

							
										</ul>
		</div>
	</div> <!-- .category_footer -->
</section>
<!-- /Block categories module -->
<?php }} ?>
