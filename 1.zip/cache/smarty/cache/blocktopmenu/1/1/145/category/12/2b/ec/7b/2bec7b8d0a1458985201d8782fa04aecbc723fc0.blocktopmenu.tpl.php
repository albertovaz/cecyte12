<?php /*%%SmartyHeaderCode:706257a8d69937ef75-88244318%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2bec7b8d0a1458985201d8782fa04aecbc723fc0' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda\\themes\\default-bootstrap\\modules\\blocktopmenu\\blocktopmenu.tpl',
      1 => 1470677546,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '706257a8d69937ef75-88244318',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab3328b5f9f8_07446408',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab3328b5f9f8_07446408')) {function content_57ab3328b5f9f8_07446408($_smarty_tpl) {?>	<!-- Menu -->
	<div id="block_top_menu" class="sf-contener clearfix col-lg-12">
		<div class="cat-title">Menú</div>
		<ul class="sf-menu clearfix menu-content">
			<li class="sfHoverForce"><a href="http://localhost/tienda/12-gadgets" title="Gadgets">Gadgets</a></li>
					</ul>
	</div>
	<!--/ Menu -->
<?php }} ?>
