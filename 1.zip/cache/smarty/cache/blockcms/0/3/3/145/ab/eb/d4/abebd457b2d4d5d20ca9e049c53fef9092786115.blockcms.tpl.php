<?php /*%%SmartyHeaderCode:2333057a8d699ae9830-21714683%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'abebd457b2d4d5d20ca9e049c53fef9092786115' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda\\themes\\default-bootstrap\\modules\\blockcms\\blockcms.tpl',
      1 => 1470677545,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2333057a8d699ae9830-21714683',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab331bc665b6_20315357',
  'has_nocache_code' => true,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab331bc665b6_20315357')) {function content_57ab331bc665b6_20315357($_smarty_tpl) {?>
	<!-- Block CMS module -->
			<section id="informations_block_left_1" class="block informations_block_left">
			<p class="title_block">
				<a href="http://localhost/tienda/content/category/1-inicio">
					Información				</a>
			</p>
			<div class="block_content list-block">
				<ul>
																							<li>
								<a href="http://localhost/tienda/content/1-entrega" title="Envío">
									Envío
								</a>
							</li>
																								<li>
								<a href="http://localhost/tienda/content/2-aviso-legal" title="Aviso legal">
									Aviso legal
								</a>
							</li>
																								<li>
								<a href="http://localhost/tienda/content/3-terminos-y-condiciones-de-uso" title="Términos y condiciones">
									Términos y condiciones
								</a>
							</li>
																								<li>
								<a href="http://localhost/tienda/content/4-sobre-nosotros" title="Sobre nosotros">
									Sobre nosotros
								</a>
							</li>
																								<li>
								<a href="http://localhost/tienda/content/5-pago-seguro" title="Pago seguro">
									Pago seguro
								</a>
							</li>
																						<li>
							<a href="http://localhost/tienda/tiendas" title="Nuestras tiendas">
								Nuestras tiendas
							</a>
						</li>
									</ul>
			</div>
		</section>
		<!-- /Block CMS module -->
<?php }} ?>
