<?php /*%%SmartyHeaderCode:3234457aa054947e0e6-77983822%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '94e186469ea1d636b546041b772ab5ad018cb0cb' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda\\modules\\homefeatured\\views\\templates\\hook\\tab.tpl',
      1 => 1470677535,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3234457aa054947e0e6-77983822',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab59c5403803_70636863',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab59c5403803_70636863')) {function content_57ab59c5403803_70636863($_smarty_tpl) {?><li><a data-toggle="tab" href="#homefeatured" class="homefeatured">Populares</a></li><?php }} ?>
