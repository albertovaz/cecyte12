<?php /*%%SmartyHeaderCode:2407957a8d69ab5b066-88852597%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '683100114747968523704f12f0b98ca0690da575' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda\\themes\\default-bootstrap\\modules\\blockcontact\\nav.tpl',
      1 => 1470677545,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2407957a8d69ab5b066-88852597',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab32b5f2eaf4_92577192',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab32b5f2eaf4_92577192')) {function content_57ab32b5f2eaf4_92577192($_smarty_tpl) {?><div id="contact-link" >
	<a href="http://localhost/tienda/contactanos" title="Contacte con nosotros">Contacte con nosotros</a>
</div>
	<span class="shop-phone">
		<i class="icon-phone"></i>Llámanos ahora: <strong>0123-456-789</strong>
	</span>
<?php }} ?>
