<?php /*%%SmartyHeaderCode:3185457aa05ad037793-97949114%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ad306e667b9a66f93e547e8f0c300ea9be280beb' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda\\themes\\default-bootstrap\\modules\\blockstore\\blockstore.tpl',
      1 => 1470677546,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3185457aa05ad037793-97949114',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab33293e1c46_91389065',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab33293e1c46_91389065')) {function content_57ab33293e1c46_91389065($_smarty_tpl) {?>
<!-- Block stores module -->
<div id="stores_block_left" class="block">
	<p class="title_block">
		<a href="http://localhost/tienda/tiendas" title="Nuestras tiendas">
			Nuestras tiendas
		</a>
	</p>
	<div class="block_content blockstore">
		<p class="store_image">
			<a href="http://localhost/tienda/tiendas" title="Nuestras tiendas">
				<img class="img-responsive" src="http://localhost/tienda/modules/blockstore/store.jpg" alt="Nuestras tiendas" />
			</a>
		</p>
				<div>
			<a 
			class="btn btn-default button button-small" 
			href="http://localhost/tienda/tiendas" 
			title="Nuestras tiendas">
				<span>Descubra nuestras tiendas<i class="icon-chevron-right right"></i></span>
			</a>
		</div>
	</div>
</div>
<!-- /Block stores module -->
<?php }} ?>
