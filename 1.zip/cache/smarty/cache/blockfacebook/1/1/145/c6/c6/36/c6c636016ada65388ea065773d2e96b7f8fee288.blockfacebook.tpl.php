<?php /*%%SmartyHeaderCode:2078957aa0548447245-36468284%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c6c636016ada65388ea065773d2e96b7f8fee288' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda\\modules\\blockfacebook\\blockfacebook.tpl',
      1 => 1470677528,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2078957aa0548447245-36468284',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab59c4a160e2_30660349',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab59c4a160e2_30660349')) {function content_57ab59c4a160e2_30660349($_smarty_tpl) {?><div id="fb-root"></div>
<div id="facebook_block" class="col-xs-4">
	<h4 >Síguenos en Facebook</h4>
	<div class="facebook-fanbox">
		<div class="fb-like-box" data-href="https://www.facebook.com/prestashop" data-colorscheme="light" data-show-faces="true" data-header="false" data-stream="false" data-show-border="false">
		</div>
	</div>
</div>
<?php }} ?>
